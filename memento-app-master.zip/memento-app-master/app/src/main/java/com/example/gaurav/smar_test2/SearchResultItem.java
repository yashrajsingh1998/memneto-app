package com.example.gaurav.smar_test2;

/**
 * Created by gaurav on 3/2/17.
 */
public class SearchResultItem {
    public String type;
    public String ts;
    public String text;
}
