package com.example.gaurav.smar_test2;

/**
 * Created by gaurav on 3/2/17.
 */
public class SearchResult {
    public long _id;
    public String ts;
    public String speech_text;
    public String vision_text;
    public String face_text;
}
